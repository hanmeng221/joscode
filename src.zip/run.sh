#/bin/bash
find . -name '*.v' | xargs -I {} cp {} joscode
find . -name '*.cdc' | xargs -I {} cp {} joscode
find . -name '*.ucf' | xargs -I {} cp {} joscode
