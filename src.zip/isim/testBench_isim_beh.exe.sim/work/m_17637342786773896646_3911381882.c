/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/xls2/jos2/mips/datapath/MemExtender.v";
static unsigned int ng1[] = {4U, 0U};
static unsigned int ng2[] = {2U, 0U};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {16, 0};
static unsigned int ng5[] = {3U, 0U};
static unsigned int ng6[] = {0U, 0U};
static int ng7[] = {24, 0};



static void Always_9_0(char *t0)
{
    char t9[8];
    char t16[8];
    char t38[8];
    char t39[8];
    char t49[8];
    char t53[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    char *t50;
    char *t51;
    char *t52;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(9, ng0);
    t2 = (t0 + 3000);
    *((int *)t2) = 1;
    t3 = (t0 + 2712);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(10, ng0);

LAB5:    xsi_set_current_line(11, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t4, 3);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t6 == 1)
        goto LAB15;

LAB16:
LAB17:    goto LAB2;

LAB7:    xsi_set_current_line(12, ng0);
    t7 = (t0 + 1368U);
    t8 = *((char **)t7);
    t7 = (t0 + 1768);
    xsi_vlogvar_assign_value(t7, t8, 0, 0, 32);
    goto LAB17;

LAB9:    xsi_set_current_line(13, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    memset(t9, 0, 8);
    t3 = (t9 + 4);
    t7 = (t4 + 4);
    t10 = *((unsigned int *)t4);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t9) = t12;
    t13 = *((unsigned int *)t7);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t3) = t15;
    t8 = ((char*)((ng3)));
    memset(t16, 0, 8);
    t17 = (t9 + 4);
    t18 = (t8 + 4);
    t19 = *((unsigned int *)t9);
    t20 = *((unsigned int *)t8);
    t21 = (t19 ^ t20);
    t22 = *((unsigned int *)t17);
    t23 = *((unsigned int *)t18);
    t24 = (t22 ^ t23);
    t25 = (t21 | t24);
    t26 = *((unsigned int *)t17);
    t27 = *((unsigned int *)t18);
    t28 = (t26 | t27);
    t29 = (~(t28));
    t30 = (t25 & t29);
    if (t30 != 0)
        goto LAB21;

LAB18:    if (t28 != 0)
        goto LAB20;

LAB19:    *((unsigned int *)t16) = 1;

LAB21:    t32 = (t16 + 4);
    t33 = *((unsigned int *)t32);
    t34 = (~(t33));
    t35 = *((unsigned int *)t16);
    t36 = (t35 & t34);
    t37 = (t36 != 0);
    if (t37 > 0)
        goto LAB22;

LAB23:    xsi_set_current_line(16, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t16, 0, 8);
    t2 = (t16 + 4);
    t4 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 0);
    *((unsigned int *)t16) = t11;
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 0);
    *((unsigned int *)t2) = t13;
    t14 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t14 & 65535U);
    t15 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t15 & 65535U);
    t7 = ((char*)((ng4)));
    t8 = (t0 + 1368U);
    t17 = *((char **)t8);
    memset(t39, 0, 8);
    t8 = (t39 + 4);
    t18 = (t17 + 4);
    t19 = *((unsigned int *)t17);
    t20 = (t19 >> 15);
    t21 = (t20 & 1);
    *((unsigned int *)t39) = t21;
    t22 = *((unsigned int *)t18);
    t23 = (t22 >> 15);
    t24 = (t23 & 1);
    *((unsigned int *)t8) = t24;
    xsi_vlog_mul_concat(t38, 16, 1, t7, 1U, t39, 1);
    xsi_vlogtype_concat(t9, 32, 32, 2U, t38, 16, t16, 16);
    t31 = (t0 + 1768);
    xsi_vlogvar_assign_value(t31, t9, 0, 0, 32);

LAB24:    goto LAB17;

LAB11:    xsi_set_current_line(18, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    memset(t9, 0, 8);
    t3 = (t9 + 4);
    t7 = (t4 + 4);
    t10 = *((unsigned int *)t4);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t9) = t12;
    t13 = *((unsigned int *)t7);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t3) = t15;
    t8 = ((char*)((ng3)));
    memset(t16, 0, 8);
    t17 = (t9 + 4);
    t18 = (t8 + 4);
    t19 = *((unsigned int *)t9);
    t20 = *((unsigned int *)t8);
    t21 = (t19 ^ t20);
    t22 = *((unsigned int *)t17);
    t23 = *((unsigned int *)t18);
    t24 = (t22 ^ t23);
    t25 = (t21 | t24);
    t26 = *((unsigned int *)t17);
    t27 = *((unsigned int *)t18);
    t28 = (t26 | t27);
    t29 = (~(t28));
    t30 = (t25 & t29);
    if (t30 != 0)
        goto LAB28;

LAB25:    if (t28 != 0)
        goto LAB27;

LAB26:    *((unsigned int *)t16) = 1;

LAB28:    t32 = (t16 + 4);
    t33 = *((unsigned int *)t32);
    t34 = (~(t33));
    t35 = *((unsigned int *)t16);
    t36 = (t35 & t34);
    t37 = (t36 != 0);
    if (t37 > 0)
        goto LAB29;

LAB30:    xsi_set_current_line(21, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t16, 0, 8);
    t2 = (t16 + 4);
    t4 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 0);
    *((unsigned int *)t16) = t11;
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 0);
    *((unsigned int *)t2) = t13;
    t14 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t14 & 65535U);
    t15 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t15 & 65535U);
    t7 = ((char*)((ng6)));
    xsi_vlogtype_concat(t9, 32, 32, 2U, t7, 16, t16, 16);
    t8 = (t0 + 1768);
    xsi_vlogvar_assign_value(t8, t9, 0, 0, 32);

LAB31:    goto LAB17;

LAB13:    xsi_set_current_line(23, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng6)));
    memset(t9, 0, 8);
    t7 = (t4 + 4);
    t8 = (t3 + 4);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t3);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t7);
    t21 = *((unsigned int *)t8);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB35;

LAB32:    if (t22 != 0)
        goto LAB34;

LAB33:    *((unsigned int *)t9) = 1;

LAB35:    t18 = (t9 + 4);
    t25 = *((unsigned int *)t18);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB36;

LAB37:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng3)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB42;

LAB39:    if (t22 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t9) = 1;

LAB42:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB43;

LAB44:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng2)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB49;

LAB46:    if (t22 != 0)
        goto LAB48;

LAB47:    *((unsigned int *)t9) = 1;

LAB49:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB56;

LAB53:    if (t22 != 0)
        goto LAB55;

LAB54:    *((unsigned int *)t9) = 1;

LAB56:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB57;

LAB58:
LAB59:
LAB52:
LAB45:
LAB38:    goto LAB17;

LAB15:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng6)));
    memset(t9, 0, 8);
    t7 = (t4 + 4);
    t8 = (t3 + 4);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t3);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t7);
    t21 = *((unsigned int *)t8);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB63;

LAB60:    if (t22 != 0)
        goto LAB62;

LAB61:    *((unsigned int *)t9) = 1;

LAB63:    t18 = (t9 + 4);
    t25 = *((unsigned int *)t18);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB64;

LAB65:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng3)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB70;

LAB67:    if (t22 != 0)
        goto LAB69;

LAB68:    *((unsigned int *)t9) = 1;

LAB70:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB71;

LAB72:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng2)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB77;

LAB74:    if (t22 != 0)
        goto LAB76;

LAB75:    *((unsigned int *)t9) = 1;

LAB77:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB78;

LAB79:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t9, 0, 8);
    t4 = (t3 + 4);
    t7 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t7);
    t15 = (t13 ^ t14);
    t19 = (t12 | t15);
    t20 = *((unsigned int *)t4);
    t21 = *((unsigned int *)t7);
    t22 = (t20 | t21);
    t23 = (~(t22));
    t24 = (t19 & t23);
    if (t24 != 0)
        goto LAB84;

LAB81:    if (t22 != 0)
        goto LAB83;

LAB82:    *((unsigned int *)t9) = 1;

LAB84:    t17 = (t9 + 4);
    t25 = *((unsigned int *)t17);
    t26 = (~(t25));
    t27 = *((unsigned int *)t9);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB85;

LAB86:
LAB87:
LAB80:
LAB73:
LAB66:    goto LAB17;

LAB20:    t31 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t31) = 1;
    goto LAB21;

LAB22:    xsi_set_current_line(14, ng0);
    t40 = (t0 + 1368U);
    t41 = *((char **)t40);
    memset(t39, 0, 8);
    t40 = (t39 + 4);
    t42 = (t41 + 4);
    t43 = *((unsigned int *)t41);
    t44 = (t43 >> 16);
    *((unsigned int *)t39) = t44;
    t45 = *((unsigned int *)t42);
    t46 = (t45 >> 16);
    *((unsigned int *)t40) = t46;
    t47 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t47 & 65535U);
    t48 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t48 & 65535U);
    t50 = ((char*)((ng4)));
    t51 = (t0 + 1368U);
    t52 = *((char **)t51);
    memset(t53, 0, 8);
    t51 = (t53 + 4);
    t54 = (t52 + 4);
    t55 = *((unsigned int *)t52);
    t56 = (t55 >> 31);
    t57 = (t56 & 1);
    *((unsigned int *)t53) = t57;
    t58 = *((unsigned int *)t54);
    t59 = (t58 >> 31);
    t60 = (t59 & 1);
    *((unsigned int *)t51) = t60;
    xsi_vlog_mul_concat(t49, 16, 1, t50, 1U, t53, 1);
    xsi_vlogtype_concat(t38, 32, 32, 2U, t49, 16, t39, 16);
    t61 = (t0 + 1768);
    xsi_vlogvar_assign_value(t61, t38, 0, 0, 32);
    goto LAB24;

LAB27:    t31 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t31) = 1;
    goto LAB28;

LAB29:    xsi_set_current_line(19, ng0);
    t40 = (t0 + 1368U);
    t41 = *((char **)t40);
    memset(t39, 0, 8);
    t40 = (t39 + 4);
    t42 = (t41 + 4);
    t43 = *((unsigned int *)t41);
    t44 = (t43 >> 16);
    *((unsigned int *)t39) = t44;
    t45 = *((unsigned int *)t42);
    t46 = (t45 >> 16);
    *((unsigned int *)t40) = t46;
    t47 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t47 & 65535U);
    t48 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t48 & 65535U);
    t50 = ((char*)((ng6)));
    xsi_vlogtype_concat(t38, 32, 32, 2U, t50, 16, t39, 16);
    t51 = (t0 + 1768);
    xsi_vlogvar_assign_value(t51, t38, 0, 0, 32);
    goto LAB31;

LAB34:    t17 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t17) = 1;
    goto LAB35;

LAB36:    xsi_set_current_line(24, ng0);
    t31 = (t0 + 1368U);
    t32 = *((char **)t31);
    memset(t38, 0, 8);
    t31 = (t38 + 4);
    t40 = (t32 + 4);
    t30 = *((unsigned int *)t32);
    t33 = (t30 >> 0);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t40);
    t35 = (t34 >> 0);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t37 & 255U);
    t41 = ((char*)((ng7)));
    t42 = (t0 + 1368U);
    t50 = *((char **)t42);
    memset(t49, 0, 8);
    t42 = (t49 + 4);
    t51 = (t50 + 4);
    t43 = *((unsigned int *)t50);
    t44 = (t43 >> 7);
    t45 = (t44 & 1);
    *((unsigned int *)t49) = t45;
    t46 = *((unsigned int *)t51);
    t47 = (t46 >> 7);
    t48 = (t47 & 1);
    *((unsigned int *)t42) = t48;
    xsi_vlog_mul_concat(t39, 24, 1, t41, 1U, t49, 1);
    xsi_vlogtype_concat(t16, 32, 32, 2U, t39, 24, t38, 8);
    t52 = (t0 + 1768);
    xsi_vlogvar_assign_value(t52, t16, 0, 0, 32);
    goto LAB38;

LAB41:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB42;

LAB43:    xsi_set_current_line(26, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 8);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 8);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng7)));
    t41 = (t0 + 1368U);
    t42 = *((char **)t41);
    memset(t49, 0, 8);
    t41 = (t49 + 4);
    t50 = (t42 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (t43 >> 15);
    t45 = (t44 & 1);
    *((unsigned int *)t49) = t45;
    t46 = *((unsigned int *)t50);
    t47 = (t46 >> 15);
    t48 = (t47 & 1);
    *((unsigned int *)t41) = t48;
    xsi_vlog_mul_concat(t39, 24, 1, t40, 1U, t49, 1);
    xsi_vlogtype_concat(t16, 32, 32, 2U, t39, 24, t38, 8);
    t51 = (t0 + 1768);
    xsi_vlogvar_assign_value(t51, t16, 0, 0, 32);
    goto LAB45;

LAB48:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB49;

LAB50:    xsi_set_current_line(28, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 16);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 16);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng7)));
    t41 = (t0 + 1368U);
    t42 = *((char **)t41);
    memset(t49, 0, 8);
    t41 = (t49 + 4);
    t50 = (t42 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (t43 >> 23);
    t45 = (t44 & 1);
    *((unsigned int *)t49) = t45;
    t46 = *((unsigned int *)t50);
    t47 = (t46 >> 23);
    t48 = (t47 & 1);
    *((unsigned int *)t41) = t48;
    xsi_vlog_mul_concat(t39, 24, 1, t40, 1U, t49, 1);
    xsi_vlogtype_concat(t16, 32, 32, 2U, t39, 24, t38, 8);
    t51 = (t0 + 1768);
    xsi_vlogvar_assign_value(t51, t16, 0, 0, 32);
    goto LAB52;

LAB55:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB56;

LAB57:    xsi_set_current_line(30, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 24);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 24);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng7)));
    t41 = (t0 + 1368U);
    t42 = *((char **)t41);
    memset(t49, 0, 8);
    t41 = (t49 + 4);
    t50 = (t42 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (t43 >> 31);
    t45 = (t44 & 1);
    *((unsigned int *)t49) = t45;
    t46 = *((unsigned int *)t50);
    t47 = (t46 >> 31);
    t48 = (t47 & 1);
    *((unsigned int *)t41) = t48;
    xsi_vlog_mul_concat(t39, 24, 1, t40, 1U, t49, 1);
    xsi_vlogtype_concat(t16, 32, 32, 2U, t39, 24, t38, 8);
    t51 = (t0 + 1768);
    xsi_vlogvar_assign_value(t51, t16, 0, 0, 32);
    goto LAB59;

LAB62:    t17 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t17) = 1;
    goto LAB63;

LAB64:    xsi_set_current_line(33, ng0);
    t31 = (t0 + 1368U);
    t32 = *((char **)t31);
    memset(t38, 0, 8);
    t31 = (t38 + 4);
    t40 = (t32 + 4);
    t30 = *((unsigned int *)t32);
    t33 = (t30 >> 0);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t40);
    t35 = (t34 >> 0);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t37 & 255U);
    t41 = ((char*)((ng6)));
    xsi_vlogtype_concat(t16, 32, 32, 2U, t41, 24, t38, 8);
    t42 = (t0 + 1768);
    xsi_vlogvar_assign_value(t42, t16, 0, 0, 32);
    goto LAB66;

LAB69:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB70;

LAB71:    xsi_set_current_line(35, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 8);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 8);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng6)));
    xsi_vlogtype_concat(t16, 32, 32, 2U, t40, 24, t38, 8);
    t41 = (t0 + 1768);
    xsi_vlogvar_assign_value(t41, t16, 0, 0, 32);
    goto LAB73;

LAB76:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB77;

LAB78:    xsi_set_current_line(37, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 16);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 16);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng6)));
    xsi_vlogtype_concat(t16, 32, 32, 2U, t40, 24, t38, 8);
    t41 = (t0 + 1768);
    xsi_vlogvar_assign_value(t41, t16, 0, 0, 32);
    goto LAB80;

LAB83:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB84;

LAB85:    xsi_set_current_line(39, ng0);
    t18 = (t0 + 1368U);
    t31 = *((char **)t18);
    memset(t38, 0, 8);
    t18 = (t38 + 4);
    t32 = (t31 + 4);
    t30 = *((unsigned int *)t31);
    t33 = (t30 >> 24);
    *((unsigned int *)t38) = t33;
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 24);
    *((unsigned int *)t18) = t35;
    t36 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t36 & 255U);
    t37 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t37 & 255U);
    t40 = ((char*)((ng6)));
    xsi_vlogtype_concat(t16, 32, 32, 2U, t40, 24, t38, 8);
    t41 = (t0 + 1768);
    xsi_vlogvar_assign_value(t41, t16, 0, 0, 32);
    goto LAB87;

}


extern void work_m_17637342786773896646_3911381882_init()
{
	static char *pe[] = {(void *)Always_9_0};
	xsi_register_didat("work_m_17637342786773896646_3911381882", "isim/testBench_isim_beh.exe.sim/work/m_17637342786773896646_3911381882.didat");
	xsi_register_executes(pe);
}
