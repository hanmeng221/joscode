/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/xls2/jos2/mips/datapath/HILO.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {3U, 0U};
static unsigned int ng5[] = {4U, 0U};
static unsigned int ng6[] = {5U, 0U};



static void Cont_17_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 3640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4568);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 4456);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_18_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 3888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 2568);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4632);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 4472);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Always_20_2(char *t0)
{
    char t17[16];
    char t18[8];
    char t20[16];
    char t21[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t19;

LAB0:    t1 = (t0 + 4136U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(20, ng0);
    t2 = (t0 + 4488);
    *((int *)t2) = 1;
    t3 = (t0 + 4168);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(21, ng0);

LAB5:    xsi_set_current_line(22, ng0);
    t4 = (t0 + 1688U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(23, ng0);
    t11 = (t0 + 1528U);
    t12 = *((char **)t11);

LAB9:    t11 = ((char*)((ng1)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t11, 3);
    if (t13 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng2)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t2, 3);
    if (t13 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng3)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t2, 3);
    if (t13 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng4)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t2, 3);
    if (t13 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng5)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t2, 3);
    if (t13 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng6)));
    t13 = xsi_vlog_unsigned_case_compare(t12, 3, t2, 3);
    if (t13 == 1)
        goto LAB20;

LAB21:
LAB22:    goto LAB8;

LAB10:    xsi_set_current_line(24, ng0);

LAB23:    xsi_set_current_line(25, ng0);
    t14 = (t0 + 1208U);
    t15 = *((char **)t14);
    t14 = (t0 + 1368U);
    t16 = *((char **)t14);
    xsi_vlog_signed_multiply(t17, 64, t15, 32, t16, 32);
    t14 = (t0 + 2728);
    xsi_vlogvar_assign_value(t14, t17, 0, 0, 64);
    xsi_set_current_line(26, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t5 = (t18 + 4);
    t11 = (t4 + 8);
    t14 = (t4 + 12);
    t6 = *((unsigned int *)t11);
    t7 = (t6 >> 0);
    *((unsigned int *)t18) = t7;
    t8 = *((unsigned int *)t14);
    t9 = (t8 >> 0);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t10 & 4294967295U);
    t19 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t19 & 4294967295U);
    t15 = (t0 + 2408);
    xsi_vlogvar_assign_value(t15, t18, 0, 0, 32);
    xsi_set_current_line(27, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t5 = (t18 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t18) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 0);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t10 & 4294967295U);
    t19 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t19 & 4294967295U);
    t14 = (t0 + 2568);
    xsi_vlogvar_assign_value(t14, t18, 0, 0, 32);
    goto LAB22;

LAB12:    xsi_set_current_line(29, ng0);

LAB24:    xsi_set_current_line(30, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng1)));
    xsi_vlogtype_concat(t17, 64, 33, 2U, t3, 1, t4, 32);
    t5 = (t0 + 1368U);
    t11 = *((char **)t5);
    t5 = ((char*)((ng1)));
    xsi_vlogtype_concat(t20, 64, 33, 2U, t5, 1, t11, 32);
    xsi_vlog_unsigned_multiply(t21, 64, t17, 64, t20, 64);
    t14 = (t0 + 2728);
    xsi_vlogvar_assign_value(t14, t21, 0, 0, 64);
    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t5 = (t18 + 4);
    t11 = (t4 + 8);
    t14 = (t4 + 12);
    t6 = *((unsigned int *)t11);
    t7 = (t6 >> 0);
    *((unsigned int *)t18) = t7;
    t8 = *((unsigned int *)t14);
    t9 = (t8 >> 0);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t10 & 4294967295U);
    t19 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t19 & 4294967295U);
    t15 = (t0 + 2408);
    xsi_vlogvar_assign_value(t15, t18, 0, 0, 32);
    xsi_set_current_line(32, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t5 = (t18 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t18) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 0);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t10 & 4294967295U);
    t19 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t19 & 4294967295U);
    t14 = (t0 + 2568);
    xsi_vlogvar_assign_value(t14, t18, 0, 0, 32);
    goto LAB22;

LAB14:    xsi_set_current_line(34, ng0);

LAB25:    xsi_set_current_line(35, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = (t0 + 1368U);
    t5 = *((char **)t3);
    memset(t18, 0, 8);
    xsi_vlog_signed_mod(t18, 32, t4, 32, t5, 32);
    t3 = (t0 + 2408);
    xsi_vlogvar_assign_value(t3, t18, 0, 0, 32);
    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    memset(t18, 0, 8);
    xsi_vlog_signed_divide(t18, 32, t3, 32, t4, 32);
    t2 = (t0 + 2568);
    xsi_vlogvar_assign_value(t2, t18, 0, 0, 32);
    goto LAB22;

LAB16:    xsi_set_current_line(38, ng0);

LAB26:    xsi_set_current_line(39, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng1)));
    xsi_vlogtype_concat(t17, 33, 33, 2U, t3, 1, t4, 32);
    t5 = (t0 + 1368U);
    t11 = *((char **)t5);
    t5 = ((char*)((ng1)));
    xsi_vlogtype_concat(t20, 33, 33, 2U, t5, 1, t11, 32);
    xsi_vlog_unsigned_mod(t21, 33, t17, 33, t20, 33);
    t14 = (t0 + 2408);
    xsi_vlogvar_assign_value(t14, t21, 0, 0, 32);
    xsi_set_current_line(40, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlogtype_concat(t17, 33, 33, 2U, t2, 1, t3, 32);
    t4 = (t0 + 1368U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng1)));
    xsi_vlogtype_concat(t20, 33, 33, 2U, t4, 1, t5, 32);
    xsi_vlog_unsigned_divide(t21, 33, t17, 33, t20, 33);
    t11 = (t0 + 2568);
    xsi_vlogvar_assign_value(t11, t21, 0, 0, 32);
    goto LAB22;

LAB18:    xsi_set_current_line(42, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = (t0 + 2408);
    xsi_vlogvar_assign_value(t3, t4, 0, 0, 32);
    goto LAB22;

LAB20:    xsi_set_current_line(43, ng0);
    t3 = (t0 + 1208U);
    t4 = *((char **)t3);
    t3 = (t0 + 2568);
    xsi_vlogvar_assign_value(t3, t4, 0, 0, 32);
    goto LAB22;

}


extern void work_m_18135398290056620441_0338038210_init()
{
	static char *pe[] = {(void *)Cont_17_0,(void *)Cont_18_1,(void *)Always_20_2};
	xsi_register_didat("work_m_18135398290056620441_0338038210", "isim/testBench_isim_beh.exe.sim/work/m_18135398290056620441_0338038210.didat");
	xsi_register_executes(pe);
}
